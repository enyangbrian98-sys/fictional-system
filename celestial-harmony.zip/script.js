function bookingSuccess() {
    alert("Booking Successful! Receipt sent via Email & SMS.");
}
function sendJoinRequest() {
    alert("Request submitted to admin successfully!");
}
function loginUser() {
    alert("Login successful (demo)");
}